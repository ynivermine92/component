<?php

include(DIR_LANGUAGE . 'ru/extension/module/ocfilter/filter.php');